This is my submission for the Readify coding challenge (Luke Turner).

My github repo can be found here: https://github.com/luketurnerdev/readify-robot

To run the application, either clone the above repo, or download the robot.js file from this directory.

To run, install the latest version of Node, and run the command: node robot.js.

The file will run in the console with the provided test data, as well as some supplementary test data, which can be uncommented to test.

The robot.js file can be edited inside the run() function in order to test more functionality.

